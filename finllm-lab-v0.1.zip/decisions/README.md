# Architecture Decision Records

이 디렉터리에는 프로젝트 소유자가 내린 중요한 결정을 기록한다.

권장 순서:

1. `0001-profile-a-model.md` — 8B와 14B 중 Profile A 선택
2. `0002-retrieval-design.md` — chunking, hybrid retrieval, reranker 선택
3. `0003-on-prem-packaging.md` — offline model/container 반입 방식
4. `0004-observability.md` — metric, SLO, alert 선택

ADR은 나중에 결론이 바뀌어도 삭제하지 않는다. `Superseded` 상태로 바꾸고 새
ADR을 연결한다. 이 변경 이력이 본인의 판단과 학습을 보여준다.

