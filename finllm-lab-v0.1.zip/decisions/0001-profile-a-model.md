# ADR-0001: Profile A 모델 선택

- 상태: Proposed
- 날짜: `[OWNER: YYYY-MM-DD]`
- 작성자: `[OWNER]`

## 상황

금융 내부문서 RAG를 동시 사용자 10명에게 제공하면서 P95 TTFT 2초, 품질
90점, single 24GB VRAM class를 만족해야 한다.

## 후보

- `Qwen/Qwen3-8B` BF16, revision `[OWNER]`
- `Qwen/Qwen3-14B-AWQ` AWQ 4-bit, revision `[OWNER]`

## 통제한 조건

- corpus/index version: `[OWNER]`
- evaluation set version: `[OWNER]`
- prompt revision: `[OWNER]`
- max model length: `[OWNER]`
- generation settings: `[OWNER]`
- vLLM/CUDA/driver: `[OWNER]`

## 실제 결과

| 후보 | Quality | P95 TTFT | Aggregate tok/s | Peak VRAM | Error | OOM |
|---|---:|---:|---:|---:|---:|---:|
| 8B BF16 | `[OWNER]` | `[OWNER]` | `[OWNER]` | `[OWNER]` | `[OWNER]` | `[OWNER]` |
| 14B AWQ | `[OWNER]` | `[OWNER]` | `[OWNER]` | `[OWNER]` | `[OWNER]` | `[OWNER]` |

## 결정

`[OWNER: 선택한 모델과 결정]`

## 근거

`[OWNER: 숫자와 실패 조건에 기반해 설명]`

## 포기한 것과 위험

`[OWNER: 품질, 지연시간, 비용, 하드웨어 재현성의 trade-off]`

## 추가 검증

- [ ] 24GB native GPU 실측
- [ ] 세 번 반복
- [ ] 장시간 안정성
- [ ] 운영 ACL과 prompt injection 평가

