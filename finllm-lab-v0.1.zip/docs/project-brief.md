# Project Brief

이 파일은 첫 benchmark 전에 프로젝트 소유자가 직접 수정한다. `[OWNER]`가
남아 있으면 아직 본인 프로젝트로 시작되지 않은 것이다.

## 기본 정보

- 프로젝트 이름: `[OWNER: 직접 정할 이름]`
- 소유자/역할: `[OWNER: 이름 또는 공개용 닉네임]`
- 목표 직무: 온프레미스 GenAI/LLMOps 엔지니어
- 시작일: `[OWNER: YYYY-MM-DD]`
- 첫 공개 목표일: `[OWNER: YYYY-MM-DD]`

## 권장 첫 시나리오

**은행 내부통제·준법감시팀용 Private RAG**

- 사용자: 내부통제·준법감시 담당자 10명
- 문제: 여러 규정과 업무 매뉴얼에서 근거 조항을 찾아 답변하는 시간이 길다.
- 제약: 외부 API로 원문 전송 금지, single GPU, P95 TTFT 2초
- 답변: 근거 문서와 조항을 인용하고, 근거가 없으면 답변을 유보한다.
- 데이터: 공개 금융 규정/안내서 + 직접 만든 합성 내부 규정
- 제외: 실제 고객정보, 실제 내부문서, 투자·법률 판단 자동화

다른 도메인을 택하려면 아래 중 **하나만** 첫 버전으로 선택한다.

- 회계법인: 감사기준·합성 작업문서 질의와 engagement별 ACL
- 법무법인: 계약·합성 case file 질의와 matter별 ACL

선택한 첫 시나리오: `[OWNER: 위 세 가지 중 하나]`

## 사용자와 권한

| 역할 | 볼 수 있는 문서 | 볼 수 없는 문서 |
|---|---|---|
| `[OWNER]` | `[OWNER]` | `[OWNER]` |
| `[OWNER]` | `[OWNER]` | `[OWNER]` |

반드시 증명할 권한 테스트:

- `[OWNER: 사용자 A가 볼 수 있는 문서]`
- `[OWNER: 사용자 B에게 숨겨야 하는 문서]`
- `[OWNER: 퇴사/프로젝트 종료 후 권한 회수 시나리오]`

## 성공 조건

- 동시 사용자: 10명
- P95 TTFT: 2,000ms 이하
- 오류율: 1% 이하
- OOM: 0회
- 품질: 90/100 이상
- 권한 위반 검색: 0건
- 근거 없는 질문의 올바른 답변 유보율: `[OWNER: 목표 %]`
- 모델 변경 rollback 목표시간: `[OWNER: 목표 분]`

## 첫 모델과 데이터

- 8B baseline revision: `[OWNER: commit SHA]`
- 14B AWQ revision: `[OWNER: commit SHA]`
- corpus version: `[OWNER: 예: corpus-v0.1]`
- evaluation set version: `[OWNER: 예: eval-v0.1]`
- prompt revision: `[OWNER: 예: prompt-v0.1]`

## 내 프로젝트임을 보여주는 증거

- [ ] 직접 만든 50–60개 평가 문항
- [ ] 실제 A6000 측정 result JSON 3회분
- [ ] 통과한 후보와 탈락한 후보
- [ ] 최소 3개의 ADR
- [ ] 정상/과부하 상태 dashboard
- [ ] 권한 우회와 prompt injection 실패 테스트
- [ ] 모델 변경을 막은 CI 화면
- [ ] 실제 결론과 다음 개선안

